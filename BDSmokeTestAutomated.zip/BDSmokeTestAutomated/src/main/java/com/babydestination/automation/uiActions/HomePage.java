package com.babydestination.automation.uiActions;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import com.babydestination.automation.testBase.TestBase;

public class HomePage extends TestBase {
    public static final Logger log = Logger.getLogger(HomePage.class.getName());

    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[3]/div/div/swiper/div/div[1]/div[1]")
    WebElement blog1;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[6]/div/div/swiper/div/div[1]/div[3]")
    WebElement video1;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[7]/div/div/swiper/div/div[1]/div[3]/a")

    WebElement card1;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[2]/div/div/swiper/div/div[4]")
    WebElement RArrow1;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[5]/div/div/swiper/div/div[1]/div[1]/div")
    WebElement expBlog1;
    @FindBy(xpath = "//*[@id=\"mat-input-0\"]")
    WebElement expName;
    @FindBy(xpath = "//*[@id=\"mat-input-1\"]")
    WebElement expEmail;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div[2]/app-unlock/div/app-personal-info/div/div[2]/form/div[3]/button/span")
    WebElement expSubmit;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-content/div/div[3]/div[1]/div[1]/button")
    WebElement continueReading;
    WebElement RArrow2;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[4]/div/div/div/swiper/div/div[4]")
    WebElement RArrow3;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[4]/div/div/div/swiper/div/div[1]/div[6]/div[2]/button")
    WebElement seeMoreButton1;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[4]/div/div/div/swiper/div/div[1]/div[9]/div[2]/button")
    WebElement seeMoreButton2;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[4]/div/div/div/swiper/div/div[1]/div[8]/div/div[2]/div/div/button")
    WebElement clickToAnswerHome;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[1]/div/div/div/button")
    WebElement partnerUs;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/footer/div[1]/div/div/div/swiper/div/div[1]/div[3]/a/img")
    WebElement BDNews;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/footer/div[3]/div/div/app-footer/footer/div/div/a[1]/img")
    WebElement fbFooter;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/footer/div[3]/div/div/app-footer/footer/div/div/a[2]/img")
    WebElement instaFooter;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/footer/div[3]/div/div/app-footer/footer/div/div/a[3]/img")
    WebElement twitterFooter;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/footer/div[3]/div/div/app-footer/footer/div/div/a[4]/img")
    WebElement youtubeFooter;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[2]/div/div/swiper/div/div[1]/div[1]/div/button")
    WebElement joinNowHome;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[2]/div/div/swiper/div/div[1]/div[2]/div/button")
    WebElement exploreHome;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[2]/div/div/swiper/div/div[1]/div[3]/div/button")
    WebElement askMomHome;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[2]/div/div/swiper/div/div[1]/div[4]/div/button")
    WebElement fbConnectHome;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div/div[2]/div/div/swiper/div/div[1]/div[5]/div/button")
    WebElement signupHome;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div[2]/app-user-registration/div/button")
    WebElement signupCross;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div[2]/div/app-facebook-group-join/div/div/div/button")
    WebElement fbCross;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-home/div[2]/div/app-facebook-group-join/div/div/div/div/div/div[2]/div[3]/button/a")
    WebElement joinFbConnect;
    @FindBy(id = "keyword")
    WebElement searchBox;
    @FindBy(xpath = "/html/body/app-root/app-header/div/nav/div[1]/div[1]/ul/li[2]")
    WebElement langHin;
    @FindBy(xpath = "/html/body/app-root/app-header/div/nav/div[1]/div[1]/ul/li[3]")
    WebElement langTamil;
    @FindBy(xpath = "/html/body/app-root/app-header/div/nav/div[1]/div[1]/ul/li[1]")
    WebElement langEng;
    @FindBy(xpath = "/html/body/app-root/app-header/div/nav/div[1]/div[1]/i")
    WebElement vernacularDrop;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-content/div/div[3]/div[2]/div/div[1]/div/div[2]/button")
    WebElement whatsAppjoinwidget;
    @FindBy(xpath = "/html/body/app-root/div[1]/app-forum/div[1]/div/div[1]/div[1]/div[1]/h3")
    WebElement askAnything;


    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }


    //	public void homePageBlog() throws InterruptedException {

        public void TC1() throws InterruptedException {
        pause1();
        scroll("scroll(0,750)");
        waitForElement(driver,blog1,30);
        blog1.click();
        Assert.assertEquals(continueReading.getText(),"Continue Reading");
        back();

    }

    public void TC2() throws InterruptedException {
        waitForElement(driver,partnerUs,30);
        partnerUs.click();
        scroll("scroll(0,1000)");
        pause2();
        scroll("scroll(1000,2250)");
        pause2();
        Assert.assertEquals( driver.getTitle(),"partner-with-us");
    }

    public void TC3() throws InterruptedException {
        driver.navigate().back();
        pause1();
        Assert.assertEquals(driver.getTitle(),"Home");
    }

    public void TC4() throws InterruptedException {
        scroll("scroll(0,1500)");
        waitForElement(driver,video1,60);
        pause2();
        video1.click();
        Assert.assertEquals(whatsAppjoinwidget.getText(),"Join WhatsApp Group");
        back();
    }

    public void TC4_1() throws InterruptedException {
        pause1();
        scroll("scroll(0,1200)");
        pause();
        Assert.assertEquals(driver.getTitle(),"Home" );
    }


//        log.info("page scrolled");

    public void TC5() throws InterruptedException {
        waitForElement(driver,expBlog1,60);
        expBlog1.click();
        Assert.assertEquals(expSubmit.getText(),"Unlock Now" );
    }

    //        log.info("Random blog clicked");
    public void TC6() throws InterruptedException {
        waitForElement(driver,expName,60);
        expName.sendKeys("Anuj Tiwari");
        expEmail.sendKeys("anuj@bbd.com");
        expSubmit.click();
        pause();
        waitForElement(driver,expBlog1,60);
        expBlog1.click();
        Assert.assertEquals(continueReading.getText(),"Continue Reading");
    }

    public void TC7() throws InterruptedException {
        pause2();
        back();
        Assert.assertEquals( driver.getTitle(),"Home");
    }

    public void TC8() throws InterruptedException {
        scroll("scroll(0,2000)");
        waitForElement(driver,card1,60);
        card1.click();
        Assert.assertEquals(whatsAppjoinwidget.getText(),"Join WhatsApp Group");
    }

    public void TC9() throws InterruptedException {
        pause3();
        back();
        Assert.assertEquals(driver.getTitle(),"Home" );
    }

    public void TC10() throws InterruptedException {
        waitForElement(driver,joinNowHome,60);
        joinNowHome.click();
        Assert.assertEquals( driver.getTitle(),"Whatsapp Directory");
        pause1();
        driver.navigate().back();
    }

    public void TC11() throws InterruptedException {
        waitForElement(driver,exploreHome,60);
        exploreHome.click();
        pause();
        Assert.assertEquals( driver.getTitle(),"Timeline");
        driver.navigate().back();
    }

    public void TC12() throws InterruptedException {
        pause2();
        waitForElement(driver,askMomHome,60);
        askMomHome.click();
        pause();pause();pause2();
        Assert.assertEquals(askAnything.getText(),"Ask moms anything");
        driver.navigate().back();
    }

    public void TC13() throws InterruptedException {
        waitForElement(driver,fbConnectHome,30);
        fbConnectHome.click();
        waitForElement(driver,joinFbConnect,30);
        joinFbConnect.click();
        Assert.assertEquals( joinFbConnect.getText(),"+1 JOIN");
        pause2();
        newTab();
        pause2();
        fbCross.click();
        pause1();
    }

    public void TC14() throws InterruptedException {
        RArrow1.click();
        waitForElement(driver,signupHome,60);
        signupHome.click();
        Assert.assertEquals( driver.getTitle(),"Sign-up");
        pause1();
        signupCross.click();
        pause2();
    }

    public void TC15() throws InterruptedException {
        scroll("scroll(0,1000)");
        waitForElement(driver,RArrow3,60);
        for (int i = 0; i <= 1; i++) {
            RArrow3.click();
            pause1();

        }
        Assert.assertEquals(seeMoreButton1.getText(),"SEE MORE");
        seeMoreButton1.click();pause();pause();pause3();
    }

    public void TC16() throws InterruptedException {
        waitForElement(driver,RArrow3,60);
        for (int i = 0; i <= 2; i++) {
            RArrow3.click();
            pause1();

        }
        Assert.assertEquals( seeMoreButton2.getText(),"SEE MORE");
        seeMoreButton2.click();
        pause();pause();
    }

    public void TC17() throws InterruptedException {
        waitForElement(driver,clickToAnswerHome,60);
        clickToAnswerHome.click();
        Assert.assertEquals( driver.getTitle(),"Forum Ask Question");
        driver.navigate().back();
    }

    //        RArrow2.click();
    public void TC18() throws InterruptedException {
        scroll("scroll(0,2000)");
        waitForElement(driver,fbFooter,30);
        fbFooter.click();
        Assert.assertEquals( driver.getCurrentUrl(),"https://www.facebook.com/Babydestination/");
        pause3();
        driver.navigate().back();
    }

    public void TC19() throws InterruptedException {
        waitForElement(driver,instaFooter,30);
        instaFooter.click();
        Assert.assertEquals( driver.getCurrentUrl(),"https://www.instagram.com/baby_destinationofficial/");
        pause3();
        driver.navigate().back();

    }

    public void TC20() throws InterruptedException {
        waitForElement(driver,twitterFooter,30);
        twitterFooter.click();
        Assert.assertEquals(driver.getCurrentUrl(),"https://twitter.com/@babydestination");
        pause3();
        driver.navigate().back();

    }

    public void TC21() throws InterruptedException {
        waitForElement(driver,youtubeFooter,30);
        youtubeFooter.click();
        Assert.assertEquals( driver.getCurrentUrl(),"https://www.youtube.com/channel/UCItunh2YRiNNgwvGKqhVk9Q");
        pause3();
        driver.navigate().back();

    }

    public void TC22() throws InterruptedException {
        waitForElement(driver,BDNews,30);
        BDNews.click();
        pause();
        newTab();
    }

    public void TC23() throws InterruptedException {
        searchBox.sendKeys("baby care");
        pause1();
        searchBox.sendKeys(Keys.ENTER);
        pause();
        pause1();
        Assert.assertEquals(driver.getTitle(),"baby care");
    }

    public void TC24() throws InterruptedException {
        vernacularDrop.click();
        pause1();
        langHin.click();
        pause();
        Assert.assertEquals( driver.getCurrentUrl().endsWith(".hindi.babydestination.com/home"),true);
    }

    public void TC25() throws InterruptedException {
        vernacularDrop.click();
        pause1();
        langTamil.click();
        pause();
        Assert.assertEquals( driver.getCurrentUrl().endsWith(".tamil.babydestination.com/home"),true);
        pause();

    }
//    public void TC26() throws InterruptedException {
//        vernacularDrop.click();
//        pause1();
//        langEng.click();
//        pause();
//        Assert.assertEquals( driver.getCurrentUrl().endsWith(".babydestination.com/home"),true);
//        pause();
//        driver.quit();
//    }

}


