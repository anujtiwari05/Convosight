package com.babydestination.automation.homePage;

import com.babydestination.automation.testBase.TestBase;
import com.babydestination.automation.uiActions.HomePage;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.io.IOException;

public class homePageTestCases extends TestBase {
    HomePage homePage;

    @BeforeSuite
    public void setUp()throws InterruptedException, IOException {
        init();
    }

    @Test(priority = 1)
    public void TC_001_Text_Blog() throws InterruptedException {
        homePage = new HomePage(driver);
        homePage.TC1();
    }
    @Test(priority = 2)
    public void TC_002_Partnert_Us() throws InterruptedException {

        homePage.TC2();
    }
    @Test(priority = 3)
    public void TC_003_Homepage_Navigate_from_Text() throws InterruptedException {

        homePage.TC3();
    }
    @Test(priority = 4)
    public void TC_004_Video_Blog() throws InterruptedException {

        homePage.TC4();
    }
    @Test(priority = 5,enabled = true)
    public void TC_005_Homepage_Navigate_from_Video() throws InterruptedException {

        homePage.TC4_1();
    }
    @Test(priority = 6,enabled = true)
    public void TC_006_Expert_Blog() throws InterruptedException {

        homePage.TC5();
    }
    @Test(priority = 7,enabled = true)
    public void TC_007_Expert_Popup_Submit_Blog_Clicked() throws InterruptedException {

        homePage.TC6();
    }
    @Test(priority = 8,enabled = true)
    public void TC_008_Homepage_Navigate_from_Expert() throws InterruptedException {

        homePage.TC7();
    }
    @Test(priority = 9)
    public void TC_009_Card_Blog() throws InterruptedException {

        homePage.TC8();
    }
    @Test(priority = 10)
    public void TC_010_Homepage_Navigate_from_Card() throws InterruptedException {

        homePage.TC9();
    }
    @Test(priority = 11)
    public void TC_011_JoinNow_Button_Homapage() throws InterruptedException {

        homePage.TC10();
    }
    @Test(priority = 12)
    public void TC_012_ExploreNow_Button_Homepage() throws InterruptedException {

        homePage.TC11();
    }
    @Test(priority = 13)
    public void TC_013_AskNow_Button_Homepage() throws InterruptedException {

        homePage.TC12();
    }
    @Test(priority = 14)
    public void TC_014_ConnectNow_Button_Homepage() throws InterruptedException {

        homePage.TC13();
    }
    @Test(priority = 15)
    public void TC_015_SignupNow_Button_Homepage() throws InterruptedException {

        homePage.TC14();
    }
    @Test(priority = 16)
    public void TC_016_SeeMore_Button1_Answer_Section() throws InterruptedException {

        homePage.TC15();
    }
    @Test(priority = 17)
    public void TC_017_SeeMore_Button2_Answer_Section() throws InterruptedException {

        homePage.TC16();
    }
    @Test(priority = 18)
    public void TC_018_ClickToAnswer_Button_Answer_Section_Homepage() throws InterruptedException {

        homePage.TC17();
    }
    @Test(priority = 19)
    public void TC_019_Facebook_Footer_Link() throws InterruptedException {

        homePage.TC18();
    }
    @Test(priority = 20)
    public void TC_020_Instagram_Footer_Link() throws InterruptedException {

        homePage.TC19();
    }
    @Test(priority = 21)
    public void TC_021_Twitter_Footer_Link() throws InterruptedException {

        homePage.TC20();
    }
    @Test(priority = 22)
    public void TC_022_Youtube_Footer_Link() throws InterruptedException {

        homePage.TC21();
    }
    @Test(priority = 23)
    public void TC_023_BabyDestinationNews_Random_Link() throws InterruptedException {

        homePage.TC22();
    }
    @Test(priority = 24)
    public void TC_024_Search_English_Site() throws InterruptedException {

        homePage.TC23();
    }
    @Test(priority = 25)
    public void TC_025_VernacularDropdown_Hindi_Site() throws InterruptedException {

        homePage.TC24();
    }
    @Test(priority = 26)
    public void TC_026_VernacularDropdown_Tamil_Site() throws InterruptedException {

        homePage.TC25();

    }
    @Test(priority = 27, enabled=false)
    public void TC_027_VernacularDropdown_English_Site() throws InterruptedException {

//        homePage.TC26();
    }


}
