package com.babydestination.automation.forumPage;

import com.babydestination.automation.testBase.TestBase;
import com.babydestination.automation.uiActions.forumPage;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.io.IOException;

public class forumPageTestCases extends TestBase {
    forumPage forumPage;


    @BeforeSuite
    public void setUp() throws InterruptedException, IOException {
        init();
    }

    @Test(priority = 1)
    public void TC_36_Forum_Homepage() throws InterruptedException {
        forumPage = new forumPage(driver);
        forumPage.forumsHomepage();

    }

    @Test(priority = 2,enabled = true)
    public void TC_37_Forum_Post_Question() throws InterruptedException {

        forumPage.postQuestion();

    }

    @Test(priority = 3)
    public void TC_38_Forum_Post_Answer() throws InterruptedException {

        forumPage.postAnswer();

    }


}



